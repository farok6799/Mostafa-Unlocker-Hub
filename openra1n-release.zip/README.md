# openra1n
palera1n booter for windows / s8003

## Dumped image from palera1n v2.0.0 beta 7 
- pongoOS_shellcode(already compressed).bin 
- checkra1n-kpf-ploosh.bin
- ramdisk.bin
- overlay.bin

## Usage
1. openra1n.exe
2. python3 boot.py

## Attributions
- [openra1n](https://github.com/mineek/openra1n) - Origin of the project
- [gaster](https://github.com/0x7ff/gaster) - base of the project
- [checkra1n](https://checkra.in/) - yeah, do i really need to explain this one?
- [ra1npoc15](https://github.com/kok3shidoll/ra1npoc) - payloads
